package com.spring.security.springjwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJwtApplication.class, args);
	}

}


//eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmb28iLCJleHAiOjE2Mjg5NzMyNDQsImlhdCI6MTYyODkzNzI0NH0.gy5Dg7lbs5bHbvTVFfAkOcs_pt98ms6xl0DbV14I9T4